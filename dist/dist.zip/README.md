seo-reporter
A web-app that examines websites and creates a report regarding their SEO optimizations

Attention. Windows 10 only compatibility

How to use:

Run seo-reporter.exe (allow to run untrusted app if necessary. You'll see a popup)
You should see in an opened terminal the msg about runned server if everything ok
go to http://127.0.0.1:5000 in your browser (UI tested in Chrome only) and you can see the app
insert an URL to investigate (add another if necessary)

click Explore button

you will see a result of the explored data

click on Detail button to expand SEO structure You will see SEO structure of the explored website

Click on Detail button in the tag row to see it's source